const $ = (id) => document.getElementById(id);
const esc = (t) => String(t ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const hora = (iso) => iso ? new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '';
const quando = (iso) => {
  if (!iso) return '';
  const d = new Date(iso), hoje = new Date();
  const dia = d.toDateString() === hoje.toDateString() ? 'hoje' : d.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' });
  return `${dia} ${hora(iso)}`;
};
const ha = (iso) => {
  if (!iso) return 'nunca';
  const m = Math.round((Date.now() - Date.parse(iso)) / 60e3);
  return m < 1 ? 'agora há pouco' : m < 60 ? `há ${m} min` : m < 1440 ? `há ${Math.round(m / 60)} h` : `há ${Math.round(m / 1440)} dia(s)`;
};

async function cfgLocal() {
  const v = await chrome.storage.local.get(['painel', 'chave', 'ultimo', 'pausado']);
  $('painel').value = v.painel || 'https://app.semanadobarbeiro.com.br';
  $('chave').value = v.chave || '';
  $('abrir').href = ($('painel').value || 'https://app.semanadobarbeiro.com.br') + '/admin';
  $('pausa').textContent = v.pausado ? 'Retomar envios' : 'Pausar envios';
  if (!v.chave) $('cfg').open = true;
  return v;
}

function pintaStatus(u, r, pausado) {
  const b = $('bola'); b.className = 'bola';
  if (pausado) { b.classList.add('av'); $('stTit').textContent = 'Pausado'; $('stDet').textContent = 'Nenhum aviso sai até você retomar.'; return; }
  if (!u) { $('stTit').textContent = 'WhatsApp Web fechado'; $('stDet').textContent = 'Abra web.whatsapp.com neste Chrome com o número de avisos.'; return; }
  const velho = Date.now() - u.em > 3 * 60e3;
  const mapa = { online: ['ok', 'Conectado'], enviando: ['ok', 'Enviando avisos'], aguardando: ['av', 'Aguardando o WhatsApp Web'], erro: ['er', 'Erro'], pausado: ['av', 'Pausado'] };
  const [cls, tit] = velho ? ['', 'Sem sinal do WhatsApp Web'] : (mapa[u.st] || ['', u.st]);
  if (cls) b.classList.add(cls);
  $('stTit').textContent = tit + (u.numero || r?.extensao?.numero ? ` · ${u.numero || r.extensao.numero}` : '');
  $('stDet').textContent = velho ? `Último sinal ${ha(new Date(u.em).toISOString())}. Deixe a aba do WhatsApp Web aberta.` : (u.det || '');
}

function pintaResumo(r) {
  $('sync').innerHTML = r.sync.em
    ? `Última: <b>${esc(quando(r.sync.em))}</b> (${esc(ha(r.sync.em))}) · <b>${r.destinos.total}</b> grupos, comunidades e canais encontrados`
    : 'Ainda não sincronizou. Abra o WhatsApp Web e clique em Sincronizar agora.';
  $('nAtivos').textContent = `(${r.destinos.ativos.length})`;
  $('ativos').innerHTML = r.destinos.ativos.length
    ? `<ul>${r.destinos.ativos.map(d => `<li><span>${esc(d.nome)}</span><span>${esc(d.categoria)}</span></li>`).join('')}</ul>`
    : `<div class="aviso">Nenhum grupo ativado ainda. No painel, aba <b>Grupos</b>, ative os grupos que devem receber e marque a categoria (os da turma: <b>Semana do Barbeiro</b>).</div>`;
  const f = r.fila;
  $('fila').innerHTML = (f.agora
    ? `<div><span class="num">${f.agora}</span>aviso(s) saindo agora · ${f.pendentes_agora} envio(s) pendente(s)</div>`
    : '<div>Nada para enviar agora.</div>')
    + (f.proximos.length ? `<div class="muted" style="margin:6px 0 3px">Próximos programados:</div><ul>${f.proximos.map(a => `<li><span>${esc(a.titulo)}</span><span>${esc(quando(a.agendar_em))}</span></li>`).join('')}</ul>` : '<div class="muted">Nenhum aviso programado.</div>')
    + (!r.auto ? '<div class="aviso" style="margin-top:6px">Calendário automático desligado no painel.</div>' : '');
  $('ultimos').innerHTML = r.ultimos.length
    ? `<ul>${r.ultimos.map(u => `<li title="${esc(u.erro || '')}"><span>${u.status === 'enviado' ? '✓' : '✗'} ${esc(u.destino)}</span><span>${esc(quando(u.em))}</span></li>`).join('')}</ul>`
    : 'Nenhum envio ainda.';
}

async function atualizar() {
  const v = await cfgLocal();
  if (!v.chave) { pintaStatus(v.ultimo, null, v.pausado); $('sync').textContent = 'Cole a chave da extensão em Configuração (abaixo).'; return; }
  let r = null;
  try {
    const resp = await chrome.runtime.sendMessage({ tipo: 'api', acao: 'wa_resumo' });
    if (resp?.erro) throw new Error(resp.erro);
    r = resp.ok;
    pintaResumo(r);
    $('atualizado').textContent = `atualizado ${hora(new Date().toISOString())}`;
  } catch (e) {
    $('sync').innerHTML = `<div class="aviso">${esc(e.message)}</div>`;
  }
  pintaStatus(v.ultimo, r, v.pausado);
}

$('salvar').onclick = async () => {
  const painel = $('painel').value.trim().replace(/\/$/, '');
  if (!/^https:\/\/(app\.)?semanadobarbeiro\.com\.br$/.test(painel)) { $('cfgMsg').textContent = 'Use https://app.semanadobarbeiro.com.br'; return; }
  await chrome.storage.local.set({ painel, chave: $('chave').value.trim() });
  $('cfgMsg').textContent = 'Salvo. Recarregue a aba do WhatsApp Web.';
  atualizar();
};
$('btnSync').onclick = async () => {
  await chrome.storage.local.set({ syncAgora: Date.now() });
  $('sync').textContent = 'Sincronizando no WhatsApp Web... (leva até 1 minuto)';
  setTimeout(atualizar, 15000); setTimeout(atualizar, 45000);
};
$('pausa').onclick = async () => { const { pausado } = await chrome.storage.local.get(['pausado']); await chrome.storage.local.set({ pausado: !pausado }); atualizar(); };
atualizar();
setInterval(atualizar, 15000);
chrome.storage.onChanged.addListener((c) => { if (c.ultimo || c.pausado) cfgLocal().then(v => pintaStatus(v.ultimo, null, v.pausado)); });
