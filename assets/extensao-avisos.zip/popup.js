const $ = (id) => document.getElementById(id);
async function carregar() {
  const v = await chrome.storage.local.get(['painel', 'chave', 'ultimo', 'pausado']);
  $('painel').value = v.painel || 'https://app.semanadobarbeiro.com.br';
  $('chave').value = v.chave || '';
  $('pausa').textContent = v.pausado ? 'Retomar' : 'Pausar';
  if (v.ultimo) $('st').textContent = `${v.ultimo.st}${v.ultimo.det ? ': ' + v.ultimo.det : ''} (${new Date(v.ultimo.em).toLocaleTimeString('pt-BR')})`;
}
$('salvar').onclick = async () => {
  const painel = $('painel').value.trim().replace(/\/$/, '');
  if (!/^https:\/\/(app\.)?semanadobarbeiro\.com\.br$/.test(painel)) { $('st').textContent = 'Use https://app.semanadobarbeiro.com.br'; return; }
  await chrome.storage.local.set({ painel, chave: $('chave').value.trim() });
  $('st').textContent = 'Salvo. Recarregue a aba do WhatsApp Web.';
};
$('sync').onclick = async () => { await chrome.storage.local.set({ syncAgora: Date.now() }); $('st').textContent = 'Sincronizando no WhatsApp Web...'; };
$('pausa').onclick = async () => { const { pausado } = await chrome.storage.local.get(['pausado']); await chrome.storage.local.set({ pausado: !pausado }); carregar(); };
carregar();
chrome.storage.onChanged.addListener(carregar);
