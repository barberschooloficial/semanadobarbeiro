// Roda antes da biblioteca WA-JS. Desliga o que manda dados para fora do WhatsApp:
// o Google Analytics da biblioteca e os servidores de prévia de link de terceiros
// (eles receberiam os links das mensagens). Também não muda o nome do aparelho.
window.WPPConfig = {
  disableGoogleAnalytics: true,
  googleAnalyticsId: null,
  linkPreviewApiServers: [],
  deviceName: false,
  poweredBy: null,
  sendStatusToDevice: false,
  syncAllStatus: false,
};
