// Roda só no painel (app.semanadobarbeiro.com.br/admin). Recebe a chave da extensão quando você clica em
// "Conectar extensão" na aba Grupos (a chave só aparece para quem entrou com a senha do painel).
(() => {
  window.addEventListener('message', async (ev) => {
    if (ev.source !== window || ev.origin !== 'https://app.semanadobarbeiro.com.br') return;
    const d = ev.data || {};
    if (d.tipo === 'sdb-ext-ping') return window.postMessage({ tipo: 'sdb-ext-pong', versao: chrome.runtime.getManifest().version }, ev.origin);
    if (d.tipo !== 'sdb-ext-chave' || typeof d.chave !== 'string' || d.chave.length < 16 || d.chave.length > 200) return;
    await chrome.storage.local.set({ chave: d.chave, painel: 'https://app.semanadobarbeiro.com.br', syncAgora: Date.now() });
    window.postMessage({ tipo: 'sdb-ext-ok', versao: chrome.runtime.getManifest().version }, ev.origin);
  });
})();
