// Roda dentro da página do WhatsApp Web (mundo MAIN), ao lado da WA-JS.
// Só responde a pedidos da ponte da extensão (ponte.js): estado, lista de destinos e envio.
(() => {
  if (window.__sdbAvisos) return;
  window.__sdbAvisos = true;
  const espera = (ms) => new Promise(r => setTimeout(r, ms));
  const idDe = (w) => (w && (w._serialized || (typeof w === 'string' ? w : w.toString?.()))) || '';
  const comTempo = (p, ms, msg) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(msg)), ms))]);

  async function estado() {
    const W = window.WPP;
    if (!W) return { pronto: false, motivo: 'Carregando a biblioteca' };
    if (!W.isReady) return { pronto: false, motivo: 'Aguardando o WhatsApp Web carregar' };
    const logado = W.conn?.isAuthenticated ? W.conn.isAuthenticated() : true;
    if (!logado) return { pronto: false, motivo: 'Leia o QR Code com o número de avisos' };
    let numero = '';
    try { numero = idDe(W.conn.getMyUserId()).split('@')[0].split(':')[0]; } catch {}
    return { pronto: true, numero };
  }

  async function listar() {
    const W = window.WPP;
    const out = [];
    const grupos = await W.chat.list({ onlyGroups: true });
    const avisosDeComunidade = new Set();
    for (const c of grupos) {
      const meta = c.groupMetadata || {};
      if (!meta.isParentGroup) continue;
      let anuncio = '';
      try { anuncio = idDe(W.community.getAnnouncementGroup(c.id)); } catch {}
      if (anuncio) avisosDeComunidade.add(anuncio);
      let admin = false;
      try { admin = anuncio ? await W.group.iAmAdmin(anuncio) : await W.group.iAmAdmin(c.id); } catch {}
      out.push({ id: idDe(c.id), nome: c.name || c.formattedTitle || meta.subject || '', tipo: 'comunidade', envio_id: anuncio || idDe(c.id), admin, participantes: meta.participants?.length ?? null });
    }
    for (const c of grupos) {
      const meta = c.groupMetadata || {};
      const id = idDe(c.id);
      if (meta.isParentGroup || avisosDeComunidade.has(id)) continue;
      let admin = false;
      try { admin = await W.group.iAmAdmin(c.id); } catch {}
      out.push({ id, nome: c.name || c.formattedTitle || meta.subject || '', tipo: 'grupo', admin, participantes: meta.participants?.length ?? null });
    }
    let canais = [];
    try { canais = await W.chat.list({ onlyNewsletter: true }); } catch {}
    for (const c of canais) {
      const m = c.newsletterMetadata || {};
      const papel = String(m.membershipType || m.role || m.viewerMetadata?.role || '').toLowerCase();
      out.push({ id: idDe(c.id), nome: c.name || m.name || '', tipo: 'canal', admin: papel ? ['owner', 'admin'].includes(papel) : null, participantes: m.subscribersCount ?? m.size ?? null });
    }
    return out;
  }

  async function enviar({ para, texto }) {
    const W = window.WPP;
    const canal = String(para).endsWith('@newsletter');
    // "digitando..." por alguns segundos, como uma pessoa faria
    if (!canal) {
      try { await W.chat.markIsComposing(para, 4000); } catch {}
      await espera(2500 + Math.random() * 2500);
    }
    const r = await W.chat.sendTextMessage(para, texto, { createChat: true, linkPreview: false });
    if (r?.sendMsgResult) {
      const res = await comTempo(Promise.resolve(r.sendMsgResult), 45000, 'O WhatsApp não confirmou o envio');
      const st = res?.messageSendResult ?? res;
      if (st && typeof st === 'string' && !/^ok$/i.test(st)) throw new Error(`WhatsApp respondeu: ${st}`);
    }
    try { if (!canal) await W.chat.markIsPaused(para); } catch {}
    return { msg_id: idDe(r?.id) };
  }

  const CMDS = { estado, listar, enviar };
  document.addEventListener('sdb-avisos-pedido', async (ev) => {
    let d; try { d = JSON.parse(ev.detail); } catch { return; }
    const responder = (x) => document.dispatchEvent(new CustomEvent('sdb-avisos-resposta', { detail: JSON.stringify({ n: d.n, ...x }) }));
    const fn = CMDS[d.cmd];
    if (!fn) return responder({ erro: 'comando desconhecido' });
    try { responder({ ok: await fn(d.args || {}) }); }
    catch (e) { responder({ erro: String(e?.message || e).slice(0, 200) }); }
  });
})();
